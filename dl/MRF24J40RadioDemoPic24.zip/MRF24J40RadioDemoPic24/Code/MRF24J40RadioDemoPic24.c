/*
*********************************************************************************
*
*	MRF24J40RadioDemoPic24.c
*
*	MRF24J40 demo for two Explorer 16 boards with a 2.4GHz RF pictail board each.
*
*	This is based on code originally created by NERD FEVER (nerdfever.com)
*	which in turn is based on Microchip MiWi P2P stack. It is adapted by me to
*	compile for and run on a PIC24 device.
*
*	For more information visit http://nerdfever.com/?p=1797
*
*	Author: Ruben J�nsson
*	Date: 2012-03-12
*
*********************************************************************************
*/

#define _IN_MRF24J40RadioDemoPic24_

#include "hardwareprofile.h"
#include "radiohardware.h"
#include "MRF24J40.h"
#include "timedelay.h"
#include "lcdblocking.h"
#include "misc.h"

#define CYCLE_PRESC	10		// 2.56ms cycle tick

// Data payload structure for both RX and TX (same code used in both nodes).
typedef struct {
	WORD	txCnt;				// Counter incremented by sender
	UINT8	data[50];			// Dummy data payload. Make sure to keep sizeof(DATA_PAYLOAD)<=TX_PAYLOAD_SIZE
}DATA_PAYLOAD;	

static DATA_PAYLOAD txPayload;	// Structure with data to send.
static unsigned cyclePresc=1;	// For timing
static unsigned ledRxTimer=0;	// Timer for rx led
static unsigned ledTxTimer=0;	// Timer for tx led
static unsigned txTimer=0;		// Timer for txing
static unsigned rxPacket=0;		// Counter for received packets
static unsigned channel=17;		// Current RF channel to use. Must be same in both nodes.

BOOL	HandleRxPacket(void)
// Do something with the rx packet. Here the LCD is updated with data from the rx packet.
{
	sprintf((char*)LCDText,"RX:%d data:%d",rxPacket,((DATA_PAYLOAD*)(Rx.payload))->txCnt);
	sprintf((char*)&LCDText[16],"LQI=%02X RSSI=%02X",Rx.lqi,Rx.rssi);
	
	LCDUpdate();
	return TRUE;
}

void RadioInitP2P(void)
// Initialize the tx packet. This only needs to be done once if the framecontrol and dest address isn't
// changed - as here.
{
	Tx.frameControl.frameType = PACKET_TYPE_DATA;
	Tx.frameControl.securityEnabled = 0;
	Tx.frameControl.framePending = 0;
	Tx.frameControl.ackRequest = 1;
	Tx.frameControl.panIDcomp = 1;
	Tx.frameControl.dstAddrMode = SHORT_ADDR_FIELD;
	Tx.frameControl.frameVersion = 0;
	Tx.frameControl.srcAddrMode = NO_ADDR_FIELD;
	Tx.dstPANID = RadioStatus.MyPANID;
	Tx.dstAddr = RadioStatus.MyShortAddress;		// Both nodes for this demo uses the same addresses.
	Tx.payload = (BYTE*)&txPayload;
	Tx.payloadLength=sizeof(DATA_PAYLOAD);
}		

int main(void)
{
	int blink;
	UINT8 lastFrameNumber=0xff;
	
	BoardInit();						// Set up explorer 16 hardware (not the radio)
	RadioHW_Init(TRUE);					// Set up 2.4GHz RF pictail hardware
	LCDInit();							// Set up LCD
	TMR1On(TMR1_PERIOD,TRUE);			// Start Timer 1
	SRbits.IPL=3;						// enable CPU priority levels 4-7 interrupts
	txPayload.txCnt=0;
	
				// Blink LED_1 and LED_2 a couple of times at reset.
	for(blink=5;blink>0;blink--){
		LED_1=0;
		LED_2=1;
		DelayMs(50);
		LED_2=0;
		LED_1=1;
		if (blink!=1){
			DelayMs(50);
		}
	}
	LED_1=0;		
	
	RadioInit();						// Initialize radio
	Delay10us(20);						// Wait for it to be ready
	RadioSetChannel(channel);			// Change channel if other than default is desired.
	sprintf((char*)LCDText,"MRF24J40 on ch%d",channel);		// Welcome message on LCD
	strcpy((char*)&LCDText[16],"Waiting for RX");
	LCDUpdate();
	RadioInitP2P();						// Init Tx packet structure.
	
	//lowWrite(WRITE_RXMCR,1); // bit 0=1 => Don't filter packets on PAN/address. For test.

		// Repeat forever
	while(1){
		while(RadioRXPacket()){ 	// Anything to receive? RadioRXPacket() must be called repeatedly.
			if (Rx.frameNumber!=lastFrameNumber){	// Have we already received this packet?
													// Note that the framenumber is reset to 0 whenever RadioInit()
													// is called, so if the txing radio goes to sleep between txing
													// Rx.frameNumber can't be used here. Use a variable in the 
													// payload instead if handling duplicates matters.
													
				lastFrameNumber=Rx.frameNumber;		
				ledRxTimer=100;						// Keep rx LED on for ~250ms
				rxPacket++;							// Increment received packets counter
			
				HandleRxPacket();					// Do something with the received packet
													// Don't take too long in this routine, otherwise 
													// packets might be missed. 
			}	
			RadioDiscardPacket();					// Tell radio code that we are done with this packet.
		}
		
			// Rx LED
		if (ledRxTimer==0){
			LED_1=0;	// Off
		} else {
			LED_1=1;	// On
		}
		
			// Txing. Send a packet every ~2.5 seconds.
		if (txTimer==0){	
			ledTxTimer=100;		// Keep tx LED on for ~250ms
			txTimer=1000;
			txPayload.txCnt++;	// Increment tx counter displayed by the receiver
			RadioTXPacket();	// Payload has already been set up and isn't changed
		}
		
			// Tx LED
		if (ledTxTimer==0){
			LED_2=0;	// Off
		} else {
			LED_2=1;	// On
		}
	}
	return 0;
}

void __attribute__((interrupt,shadow,auto_psv)) _T1Interrupt(void)
// Timer 1 interrupt routine. Set up to generate an interrupt every 256us.
// Used for general timekeeping.
{
	MRF24J40_Timer();	// Update radio timer. This is used for timeouts.
		
	// Cycle timer (2.56ms)
	cyclePresc--;
	if (cyclePresc==0){
		cyclePresc=CYCLE_PRESC;
		if (ledRxTimer!=0){
			ledRxTimer--;
		}
		if (ledTxTimer!=0){
			ledTxTimer--;
		}	
		if (txTimer!=0){
			txTimer--;
		}	
	}
	
	IFS0bits.T1IF=0;	
}

#undef _IN_MRF24J40RadioDemoPic24_




