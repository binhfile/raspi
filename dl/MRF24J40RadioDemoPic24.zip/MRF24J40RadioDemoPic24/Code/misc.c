// misc.c

#include "misc.h"

void LoopDelay(unsigned loop)
{
	while(--loop>0);
}

void	TMR1On(UINT16 period,BOOL enableInt)
{
	TMR1=0;
	PR1=period;
	T1CONbits.TCS=0;	// Internal clock source
	IPC0bits.T1IP=4;	// Priority level
	IFS0bits.T1IF=0;	// Clear interrupt flag
	if (enableInt){
		IEC0bits.T1IE=1;	// enable Timer 1 interrupt
	}
	T1CONbits.TON=1;	// Start the timer
}

void	TMR1Off()
{
	IEC0bits.T1IE=0;	// Timer 1 off	
	T1CONbits.TON=0;
}
