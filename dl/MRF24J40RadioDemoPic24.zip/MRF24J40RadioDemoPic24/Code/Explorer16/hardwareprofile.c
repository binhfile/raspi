/*
	Hardware profile for Explorer16 board for use with 
	MRF24J40RadioDemoPic24
*/

#include "hardwareprofile.h"

    _CONFIG2(FNOSC_PRI & POSCMOD_XT)                        // Primary XT OSC with 4x PLL
    _CONFIG1(JTAGEN_OFF & FWDTEN_OFF & WDTPS_PS1024)        // JTAG off, watchdog timer off

void	BoardInit(void)
{
	// Make RB0 as Digital input
    AD1PCFGbits.PCFG2 = 1;
      
    // set I/O ports
    BUTTON_1_TRIS = 1;
    BUTTON_2_TRIS = 1;
    LED_1_TRIS = 0;
    LED_2_TRIS = 0;
    LED_3_TRIS = 0;
}
