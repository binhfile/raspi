/*

HardwareProfile.h

Hardware profile for Explorer 16 board for use with 
MRF24J40RadioDemoPic24

*/

#ifndef _EXPLORER16_H_
    #define _EXPLORER16_H_    
    #include "GenericTypeDefs.h"
    #include <compiler.h>
    
    #define CLOCK_FREQ      8000000
    #define TMR1_PERIOD 1024	// 250us at 8MHz

    #define PUSH_BUTTON_1       PORTDbits.RD6
    #define PUSH_BUTTON_2       PORTDbits.RD7
    #define LED_1               LATAbits.LATA7
    #define LED_2               LATAbits.LATA6
    #define LED_3				LATAbits.LATA5
        
    #define BUTTON_1_TRIS       TRISDbits.TRISD6
    #define BUTTON_2_TRIS       TRISDbits.TRISD7
    #define LED_1_TRIS          TRISAbits.TRISA7
    #define LED_2_TRIS          TRISAbits.TRISA6
    #define	LED_3_TRIS			TRISAbits.TRISA5
        
        // Define SUPPORT_TWO_SPI if external EEPROM use the second SPI
        // port alone, not sharing SPI port with the transceiver
    #define SUPPORT_TWO_SPI
        
        // External EEPROM SPI chip select pin definition
    #define EE_nCS_TRIS         TRISDbits.TRISD12
    #define EE_nCS              LATDbits.LATD12
        
    #define TMRL TMR2
    
   	#define LCD_DATA0_TRIS		(TRISEbits.TRISE0)		// Multiplexed with LED6
   	#define LCD_DATA0_IO		(LATEbits.LATE0)
   	#define LCD_DATA1_TRIS		(TRISEbits.TRISE1)
   	#define LCD_DATA1_IO		(LATEbits.LATE1)
   	#define LCD_DATA2_TRIS		(TRISEbits.TRISE2)
   	#define LCD_DATA2_IO		(LATEbits.LATE2)
   	#define LCD_DATA3_TRIS		(TRISEbits.TRISE3)		// Multiplexed with LED3
   	#define LCD_DATA3_IO		(LATEbits.LATE3)
   	#define LCD_DATA4_TRIS		(TRISEbits.TRISE4)		// Multiplexed with LED2
   	#define LCD_DATA4_IO		(LATEbits.LATE4)
   	#define LCD_DATA5_TRIS		(TRISEbits.TRISE5)
   	#define LCD_DATA5_IO		(LATEbits.LATE5)
   	#define LCD_DATA6_TRIS		(TRISEbits.TRISE6)
   	#define LCD_DATA6_IO		(LATEbits.LATE6)
   	#define LCD_DATA7_TRIS		(TRISEbits.TRISE7)
   	#define LCD_DATA7_IO		(LATEbits.LATE7)
   	#define LCD_RD_WR_TRIS		(TRISDbits.TRISD5)
   	#define LCD_RD_WR_IO		(LATDbits.LATD5)
   	#define LCD_RS_TRIS			(TRISBbits.TRISB15)
   	#define LCD_RS_IO			(LATBbits.LATB15)
   	#define LCD_E_TRIS			(TRISDbits.TRISD4)
   	#define LCD_E_IO			(LATDbits.LATD4)
    
  
    // Following definition is for delay functionality
    #define GetInstructionClock()	(CLOCK_FREQ/2)

    void BoardInit(void);
    
#endif

