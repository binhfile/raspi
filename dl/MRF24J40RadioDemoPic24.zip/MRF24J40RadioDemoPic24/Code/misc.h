#ifndef _MISC_H_
#define _MISC_H_

#include <compiler.h>
#include <GenericTypedefs.h>

void LoopDelay(unsigned loop);
void	TMR1On(UINT16 period,BOOL enableInt);
void	TMR1Off();


#endif
